function [closest error] = closest_value(val, val_add, choices)
	choices_multiplier = 10^(floor(log10(val - val_add)));
	[error idx] = min(abs((val_add + choices*choices_multiplier - val)/val));
	closest = choices(idx)*choices_multiplier;
endfunction
