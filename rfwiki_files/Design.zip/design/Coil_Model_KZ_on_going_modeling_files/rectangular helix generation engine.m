clear
% --------Define the shape size of your sprial rectangular helix------
%left botton cornor (inner layer/outer layer)
xi=-15;
yi=-15;
xo=-30;
yo=-30;
%width & height(inner layer/outer layer)
wi=30;
hi=30;
wo=60;
ho=60;
% number of points per line per plane actual points=pn*4 per layer-4
pn=100;
%define layers along z direction vertical
lay=3;
%height of the coil
height=9;
%define turns per layer along x-y plane
turn=5;
%----------------------------------------------------------------


%--------pre calculation--------- 

%each helix define 
xbotcor=zeros(1,turn);
ybotcor=zeros(1,turn);
wtotal=zeros(1,turn);
htotal=zeros(1,turn);

xbotcor=linspace(xi,xo,turn);
ybotcor=linspace(yi,yo,turn);
wtotal=linspace(wi,wo,turn);
htotal=linspace(hi,ho,turn);

%-------define each rectangular-------
for i=1:turn
    [xstrt(i,:),ystrt(i,:)]=rectangularhelix(xbotcor(i),ybotcor(i),wtotal(i),htotal(i),pn,lay-1);
    %define z as helix
    z(i,:)=linspace(0,height,(pn*4-4)*lay);
end

for i=1:turn-1
    [xend(i,:),yend(i,:)]=rectangularhelixsmooth(xbotcor(i),ybotcor(i),xbotcor(i+1),ybotcor(i+1),wtotal(i),htotal(i),pn);
end
[xlast,ylast]=rectangularhelix(xo,yo,wo,ho,pn,1);

%----morph all rectangular and sprial------- 
xedge=[xend;xlast];
x=[xstrt xedge];
yedge=[yend;ylast];
y=[ystrt yedge];


%---------change z direction(wiring up and down and repeat)-------------
zremat=zeros(turn,(pn*4-4)*lay);
zodd=z(1:2:end,:);
zeven=flip(z(2:2:end,:),2);
zremat(1:2:end,:)=zodd;
zremat(2:2:end,:)=zeven;
z=zremat;

%---------------Final morph-------------------
sizecheck=size(x);
xreshape=reshape(x',[1,sizecheck(1)*sizecheck(2)]);
yreshape=reshape(y',[1,sizecheck(1)*sizecheck(2)]);
zreshape=reshape(z',[1,sizecheck(1)*sizecheck(2)]);

%-----------ploting---------------
% plot3(x(1,:),y(1,:),z(1,:))
%plot3([x(1,:) x(2,:)],[y(1,:) y(2,:)],[z(1,:) z(2,:)])
plot3(xreshape,yreshape,zreshape)





%-------------rectangular generation enginee-------------
function [xperlayer,yperlayer]=rectangularhelixsmooth(x0,y0,x1,y1,w,h,pn)
%calculation of sprial
xpart1= linspace(x0,x0+w,pn);
ypart1=linspace(y0,y0,pn);
xpart2=linspace(x0+w,x0+w,pn);
ypart2=linspace(y0,y0+h,pn);
xpart3=linspace(x0+w,x1,pn);
ypart3=linspace(y0+h,y0+h,pn);
xpart4=linspace(x1,x1,pn);
ypart4=linspace(y0+h,y1,pn);
xperlayer=[xpart1(1:end-1) xpart2(1:end-1) xpart3(1:end-1) xpart4(1:end-1)];
yperlayer=[ypart1(1:end-1) ypart2(1:end-1) ypart3(1:end-1) ypart4(1:end-1)];
end


function [x,y]=rectangularhelix(x0,y0,w,h,pn,lay)
%calculation of rectangular 
xpart1= linspace(x0,x0+w,pn);
ypart1=linspace(y0,y0,pn);
xpart2=linspace(x0+w,x0+w,pn);
ypart2=linspace(y0,y0+h,pn);
xpart3=flip(xpart1);
ypart3=flip(ypart1)+h;
xpart4=flip(xpart2)-w;
ypart4=flip(ypart2);
xperlayer=[xpart1(1:end-1) xpart2(1:end-1) xpart3(1:end-1) xpart4(1:end-1)];
yperlayer=[ypart1(1:end-1) ypart2(1:end-1) ypart3(1:end-1) ypart4(1:end-1)];
%reconstruct all layer x-y
x=repmat(xperlayer,1,lay);
y=repmat(yperlayer,1,lay);
end

