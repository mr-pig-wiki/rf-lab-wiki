function [X, Y, Z] = points_on_sphere(radius, num_points)
    % Generate equally spaced points on the sphere surface
    theta = linspace(0, 2*pi, num_points);
    phi = linspace(0, pi, num_points);

    [Theta, Phi] = meshgrid(theta, phi);

    X = radius * sin(Phi) .* cos(Theta);
    Y = radius * sin(Phi) .* sin(Theta);
    Z = radius * cos(Phi);
end