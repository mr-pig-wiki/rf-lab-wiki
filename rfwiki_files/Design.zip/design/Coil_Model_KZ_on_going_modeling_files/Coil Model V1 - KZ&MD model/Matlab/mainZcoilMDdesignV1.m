clear
%% coil parameters
%kz want to translate all xlable and ylable into function of xo and yo
xi=-15;%inner turn location
yi=-15;
r=1.5;%wire radius
wi=30;%coil inner hxw (xy plane)
hi=30;
pn=100;

turnmulti1=2;%must be even number
turntotal=5;

laymulti1=2;
laytotal=4;

%% parameters calculation
wicali=wi+2*r;
hicali=hi+2*r;
xprt1in=xi-r;
yprt1in=yi-r;
xprt1out=xprt1in-(turnmulti1-1)*2*r;
yprt1out=yprt1in-(turnmulti1-1)*2*r;
xprt2in=xprt1out-2*r;
yprt2in=yprt1out-2*r;
xo=xprt1in-(turntotal-1)*r*2;
yo=yprt1in-(turntotal-1)*r*2;

wprt1out=wicali+(turnmulti1-1)*4*r;
hprt1out=hicali+(turnmulti1-1)*4*r;
wprt2in=wprt1out+4*r;
hprt2in=hprt1out+4*r;
wo=wicali+4*r*(turntotal-1);
ho=hicali+4*r*(turntotal-1);

heightmulti1=(laymulti1-1)*2*r;
heightotal=(laytotal-1)*2*r;
turnrest=turntotal-turnmulti1;
%% calculation for x-y coil
xturnmax=fix(wi/(2*r)/2)


%% calculation part1 multi layer 2n turns --need to be double: turns even number
[xmulti1,ymulti1,zmulti1]=rectangular_helix_generation_engine_ridged(xprt1in,yprt1in,xprt1out,yprt1out,wicali,hicali,wprt1out,hprt1out,pn,laymulti1,heightmulti1,turnmulti1);
%% transition layer flat turn+single layer
[xsingle1,ysingle1]=rectangularhelixsmooth(xprt1out,yprt1out,xprt2in,yprt2in,wprt1out,hprt1out,pn);
zsingle1=zeros(size(xsingle1));
%% calculation rest miltilayer multi turn
[xmulti2,ymulti2,zmulti2]=rectangular_helix_generation_engine_ridged(xprt2in,yprt2in,xo,yo,wprt2in,hprt2in,wo,ho,pn,laytotal,heightotal,turnrest);

%% plot
x=[xmulti1 xsingle1 xmulti2];
y=[ymulti1 ysingle1 ymulti2];
z=[zmulti1 zsingle1 zmulti2];
%plot3(x,y,z)
save("zcoilapril2.mat","x","y","z");
plot3(xmulti1,ymulti1,zmulti1)
hold on
plot3(xmulti2,ymulti2,zmulti2)
hold on
plot3(xsingle1,ysingle1,zsingle1)



