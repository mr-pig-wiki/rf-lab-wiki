radius = 0.55;
num_points = 100;
[x, y, z] = points_on_sphere(radius, num_points);
xvec=reshape(x,1,[]);
yvec=reshape(y,1,[]);
zvec=reshape(z,1,[]);
points=[xvec;yvec;zvec];
plot3(xvec,yvec,zvec,'o')

function [X, Y, Z] = points_on_sphere(radius, num_points)
    % Generate equally spaced points on the sphere surface
    theta = linspace(0, 2*pi, num_points);
    phi = linspace(0, pi, num_points);

    [Theta, Phi] = meshgrid(theta, phi);

    X = radius * sin(Phi) .* cos(Theta);
    Y = radius * sin(Phi) .* sin(Theta);
    Z = radius * cos(Phi);
end