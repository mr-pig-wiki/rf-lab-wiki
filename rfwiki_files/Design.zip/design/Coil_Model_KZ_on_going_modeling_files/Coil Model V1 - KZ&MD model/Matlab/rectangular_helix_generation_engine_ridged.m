

function [xreshape,yreshape,zreshape]=rectangular_helix_generation_engine_ridged(xi,yi,xo,yo,wi,hi,wo,ho,pn,lay,height,turn)

%each helix define 
xbotcor=zeros(1,turn);
ybotcor=zeros(1,turn);
wtotal=zeros(1,turn);
htotal=zeros(1,turn);

xbotcor=linspace(xi,xo,turn);
ybotcor=linspace(yi,yo,turn);
wtotal=linspace(wi,wo,turn);
htotal=linspace(hi,ho,turn);

%-------define each rectangular-------
for i=1:turn
    [xstrt(i,:),ystrt(i,:)]=rectangularhelix(xbotcor(i),ybotcor(i),wtotal(i),htotal(i),pn,lay-1);
    %define z as helix
    z(i,:)=linspace(0,height,(pn*4-4)*lay);
end
if turn==1
    xend=[];
    yend=[];
else
   for i=1:turn-1
    [xend(i,:),yend(i,:)]=rectangularhelixsmooth(xbotcor(i),ybotcor(i),xbotcor(i+1),ybotcor(i+1),wtotal(i),htotal(i),pn);
   end
end

[xlast,ylast]=rectangularhelix(xo,yo,wo,ho,pn,1);

%----morph all rectangular and sprial------- 
xedge=[xend;xlast];
x=[xstrt xedge];
yedge=[yend;ylast];
y=[ystrt yedge];


%---------change z direction(wiring up and down and repeat)-------------
zremat=zeros(turn,(pn*4-4)*lay);
zodd=z(1:2:end,:);
zeven=flip(z(2:2:end,:),2);
zremat(1:2:end,:)=zodd;
zremat(2:2:end,:)=zeven;
z=zremat;

%---------------Final morph-------------------
sizecheck=size(x);
xreshape=reshape(x',[1,sizecheck(1)*sizecheck(2)]);
yreshape=reshape(y',[1,sizecheck(1)*sizecheck(2)]);
zreshape=reshape(z',[1,sizecheck(1)*sizecheck(2)]);

%-----------ploting---------------
% plot3(x(1,:),y(1,:),z(1,:))
%plot3([x(1,:) x(2,:)],[y(1,:) y(2,:)],[z(1,:) z(2,:)])
% plot3(xreshape,yreshape,zreshape)


%{
%------test case-----
clear
x0=-15;
y0=-20;
w=30;
h=40;
pn=100;
lay=1;

[x,y]=rectangularhelix(x0,y0,w,h,pn,lay);
plot(x,y)
%}

end

