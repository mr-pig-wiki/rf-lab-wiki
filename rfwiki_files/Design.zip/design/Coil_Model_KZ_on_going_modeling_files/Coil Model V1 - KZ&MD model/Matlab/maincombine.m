clear

filename1='zcoilapril2.mat';
filename2='xcoilapril2.mat';
filename3='ycoilapril2.mat';
zcoil=importdata(filename1);
xcoil=importdata(filename2);
ycoil=importdata(filename3);

zx=zcoil.x;
zy=zcoil.y;
zz=zcoil.z;

xx=xcoil.x;
xy=xcoil.y;
xz=xcoil.z;

yx=-ycoil.y;
yy=ycoil.x;
yz=ycoil.z;

%green x coil
%red y coil
%blue z coil
p1=plot3(zx,zy,zz,'b')
p1.LineWidth = 4;
hold on
p2=plot3(xx,xy,xz,'g')
p2.LineWidth = 4;
hold on
p3=plot3(yx,yy,yz,'r')
p3.LineWidth = 4;
% Improve axis appearance
set(gca, 'FontSize', 10); % Set general font size for axis ticks
set(gca, 'Box', 'on'); % Draw a box around the plot for a professional look
xlabel('mm', 'FontSize', 12); % Label for the X-axis
ylabel('mm', 'FontSize', 12); % Label for the Y-axis
zlabel('mm', 'FontSize', 12); % Label for the Z-axis
% Set the figure background color to white
set(gcf, 'Color', 'white'); % 'gcf' refers to the current figure
% Improve axis appearance
set(gca, 'FontSize', 15); % Set general font size for axis ticks
set(gca, 'Box', 'on'); % Draw a box around the plot for a professional look