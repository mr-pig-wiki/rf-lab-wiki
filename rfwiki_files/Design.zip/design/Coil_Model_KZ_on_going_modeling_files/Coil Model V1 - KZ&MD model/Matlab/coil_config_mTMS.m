function [strcoil, Coil] = coil_config_mTMS (coil_num, coil_axis)
% coil_axis order: Y-element, X-element, Z-element
w = zeros(1,3);
w(coil_axis) = 1;

theta = -0.7;
Ny = 0; Nz = 1;
MoveY = 0; MoveZ = 0;

if coil_num == 1
    Nx = 0.3; MoveX = 0.035;
elseif coil_num == 2
    Nx = -0.3; MoveX = -0.035;
end

[strcoil,Coil] = axis_weights_correct(w(1),w(2),w(3));

coilaxis = [0 0 1];

strcoil.Pwire   = meshrotate2(strcoil.Pwire, coilaxis, theta);
Coil.P          = meshrotate2(Coil.P, coilaxis, theta);
Coil.PX          = meshrotate2(Coil.PX, coilaxis, theta);
Coil.PY          = meshrotate2(Coil.PY, coilaxis, theta);
Coil.PZ          = meshrotate2(Coil.PZ, coilaxis, theta);

strcoil.Pwire = meshrotate1(strcoil.Pwire, Nx, Ny, Nz);
Coil.P        = meshrotate1(Coil.P, Nx, Ny, Nz);
Coil.PX        = meshrotate1(Coil.PX, Nx, Ny, Nz);
Coil.PY        = meshrotate1(Coil.PY, Nx, Ny, Nz);
Coil.PZ        = meshrotate1(Coil.PZ, Nx, Ny, Nz);

strcoil.Pwire(:, 1)   = strcoil.Pwire(:, 1) + MoveX;
strcoil.Pwire(:, 2)   = strcoil.Pwire(:, 2) + MoveY;
strcoil.Pwire(:, 3)   = strcoil.Pwire(:, 3) + MoveZ;
Coil.P   = Coil.P + [MoveX MoveY MoveZ];
Coil.PX   = Coil.PX + [MoveX MoveY MoveZ];
Coil.PY   = Coil.PY + [MoveX MoveY MoveZ];
Coil.PZ   = Coil.PZ + [MoveX MoveY MoveZ];
end

