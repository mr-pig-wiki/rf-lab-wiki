clear
%% coil parameter
xi=-20;
yi=-20;
xup=-20;
yup=20;
wi=40;
w2=40;
r=1.5;%wire radius
turn=6; %on each side
pn=1000; %~points per layer
rotation=20; %in deg ->angle between points and z axis
