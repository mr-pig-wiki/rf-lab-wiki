%flat 2d spiral square
%--test case--
% xi=-15;
% yi=-20;
% wi=30;
% hi=40;
% r=1.5;
% turn=5;
% pn=100;
%-------------

function [xremat,yremat,z]=spiralsquare(xi,yi,wi,hi,r,turn,pn)
%pre calculation
turnvec=(1:turn+1);
xmulti=xi-2*r*(turnvec-1);
ymulti=yi-2*r*(turnvec-1);
wmulti=wi+4*r*(turnvec-1);
wmulti=wmulti(1:end-1);
hmulti=hi+4*r*(turnvec-1);
hmulti=hmulti(1:end-1);

%cascade
for i=1:turn
    [x(i,:),y(i,:)]=rectangularhelixsmooth(xmulti(i),ymulti(i),xmulti(i+1),ymulti(i+1),wmulti(i),hmulti(i),pn);
end

xremat=reshape(x',1,[]);
yremat=reshape(y',1,[]);
z=zeros(1,length(xremat));
end
