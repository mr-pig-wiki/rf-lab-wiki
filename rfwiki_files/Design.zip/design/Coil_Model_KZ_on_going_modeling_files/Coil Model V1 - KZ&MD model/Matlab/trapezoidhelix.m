function [x,y]=trapezoidhelix(x0,y0,x1,y1,w,w2,pn,lay)
%x0,y0 botton left point; x1,y1 upper left point; w2 upper width
%points uniform distribution
trapeheight=abs(y1-y0);
side1botton=abs(x1-x0);
side2botton=abs(x0+w-x1-w2);
trapeside1=sqrt(trapeheight^2+side1botton^2);
trapeside2=sqrt(trapeheight^2+side2botton^2);
circonference=w+w2+trapeside2+trapeside1;
increpn=circonference/pn;

%points calculation
pnbt=fix(w/increpn);
pnside1=fix(trapeside1/increpn);
pnside2=fix(trapeside2/increpn);
pnup=fix(w2/increpn);

%calculation of trapezoid 
xpart1=linspace(x0,(x0+w),pnbt);
ypart1=linspace(y0,y0,length(xpart1));
xpart2=linspace((x0+w),(x1+w2),pnside2);
ypart2=linspace(y0,y1,pnside2);
xpart3=linspace((x1+w2),x1,pnup);
ypart3=linspace(y1,y1,length(xpart3));
xpart4=linspace(x1,x0,pnside1);
ypart4=linspace(y1,y0,pnside1);
xperlayer=[xpart1(1:end-1) xpart2(1:end-1) xpart3(1:end-1) xpart4(1:end-1)];
yperlayer=[ypart1(1:end-1) ypart2(1:end-1) ypart3(1:end-1) ypart4(1:end-1)];
%reconstruct all layer x-y
x=repmat(xperlayer,1,lay);
y=repmat(yperlayer,1,lay);
end