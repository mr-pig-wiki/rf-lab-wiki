clear
%% coil parameters
%kz want to translate all xlable and ylable into function of xo and yo
xi=-15;%inner turn location
yi=-15;
r=1.5;%wire radius
wi=30;%coil inner hxw (xy plane)
hi=30;
pn=100;

turnmulti1=2;%must be even number
turntotal=5;

laymulti1=2;
laytotal=3;

%% parameters calculation
x2=xi-2*r;
y2=yi-2*r;
xprt2out=x2-(turnmulti1-1)*2*r;
yprt2out=y2-(turnmulti1-1)*2*r;
xprt3in=xprt2out-2*r;
yprt3in=yprt2out-2*r;
xo=xi-(turntotal-1)*r*2;
yo=yi-(turntotal-1)*r*2;

w2=wi+r*4;
h2=hi+r*4;
wprt2out=w2+(turnmulti1-1)*4*r;
hprt2out=h2+(turnmulti1-1)*4*r;
wprt3in=wprt2out+4*r;
hprt3in=hprt2out+4*r;
wo=wi+4*r*(turntotal-1);
ho=hi+4*r*(turntotal-1);
heightmulti1=(laymulti1-1)*2*r;
heightotal=(laytotal-1)*2*r;
turnrest=turntotal-turnmulti1-1;

%% calculation part1 flat turn+single layer
[xsingle1,ysingle1]=rectangularhelixsmooth(xi,yi,x2,y2,wi,hi,pn);
zsingle1=zeros(size(xsingle1));
%% calculation part2 multi layer 2 turns --need to be double: turns even number
[xmulti2,ymulti2,zmulti2]=rectangular_helix_generation_engine_ridged(x2,y2,xprt2out,yprt2out,w2,h2,wprt2out,hprt2out,pn,laymulti1,heightmulti1,turnmulti1);
%% transition layer flat turn+single layer
[xsingle2,ysingle2]=rectangularhelixsmooth(xprt2out,yprt2out,xprt3in,yprt3in,wprt2out,hprt2out,pn);
zsingle2=zeros(size(xsingle2));
%% calculation rest miltilayer multi turn
[xmulti3,ymulti3,zmulti3]=rectangular_helix_generation_engine_ridged(xprt3in,yprt3in,xo,yo,wprt3in,hprt3in,wo,ho,pn,laytotal,heightotal,turnrest);

%% plot
x=[xsingle1 xmulti2 xsingle2 xmulti3];
y=[ysingle1 ymulti2 ysingle2 ymulti3];
z=[zsingle1 zmulti2 zsingle2 zmulti3];
plot3(x,y,z)
save("zcoilapril2.mat","x","y","z");
% plot3(xmulti3,ymulti3,zmulti3)
