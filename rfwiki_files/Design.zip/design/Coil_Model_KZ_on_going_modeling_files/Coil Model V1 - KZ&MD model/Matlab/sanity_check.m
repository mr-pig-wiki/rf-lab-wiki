clear
%% coil parameter
hi=25;
wi=40;
w2=30;
r=1.5;%wire radius
turn=6; %on each side
pn=1000; %~points per layer
rotation=20; %in deg ->angle between points and z axis
%% pre calculation
xi=-wi/2;
xup=-w2/2;
height=2*r*turn;%height vertical along yz plane
yup=hi/2;
yi=-hi/2;
%% calculation
%[y,z]=rectangularhelix(xi,yi,wi,hi,pn,turn); %rectangular coil use this

[y,z]=trapezoidhelix(xi,yi,xup,yup,wi,w2,pn,turn);

x1=linspace(-height,0,length(y));
x2=linspace(0,height,length(y));

%move to zero
zmoved=z+hi/2;

%rotate each side
z1rotate=zmoved.*cosd(rotation);
y1rotate=y;
x1rotate=x1-zmoved.*sind(rotation);


z2rotate=zmoved.*cosd(-rotation);
y2rotate=y;
x2rotate=x2-zmoved.*sind(-rotation);

plot3(x1rotate,y1rotate,z1rotate,x2rotate(1:1500),y2rotate(1:1500),z2rotate(1:1500))
x=[x1rotate x2rotate];
y=[y1rotate y2rotate];
z=[z1rotate z2rotate];
% save("sanity_checkv1.mat","x","y","z");