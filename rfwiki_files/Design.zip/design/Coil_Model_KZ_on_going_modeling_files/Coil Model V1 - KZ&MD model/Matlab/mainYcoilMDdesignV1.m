clear
%% coil parameter
xi=-20;
yi=-20;
xup=-20;
yup=20;
wi=40;
w2=40;
r=1.5;%wire radius
turn=6; %on each side
pn=1000; %~points per layer
rotation=20; %in deg ->angle between points and z axis

%% pre calculation
height=2*r*turn;%height vertical along yz plane
hi=abs(yup-yi);
%% calculation
%[y,z]=rectangularhelix(xi,yi,wi,hi,pn,turn); %rectangular coil use this

[y,z]=trapezoidhelix(xi,yi,xup,yup,wi,w2,pn,turn);
plot(y,z)

x1=linspace(0,-height,length(y));
x2=linspace(0,height,length(y));

%move to zero
zmoved=z+hi/2;

%rotate each side
z1rotate=zmoved.*cosd(rotation);
y1rotate=y;
x1rotate=x1-zmoved.*sind(rotation);
z2rotate=zmoved.*cosd(-rotation);
y2rotate=y;
x2rotate=x2-zmoved.*sind(-rotation);
plot3(x1rotate,y1rotate,z1rotate,x2rotate,y2rotate,z2rotate)
x=[x1rotate x2rotate];
y=[y1rotate y2rotate];
z=[z1rotate z2rotate];
% save("sanity_checkv1.mat","x","y","z");