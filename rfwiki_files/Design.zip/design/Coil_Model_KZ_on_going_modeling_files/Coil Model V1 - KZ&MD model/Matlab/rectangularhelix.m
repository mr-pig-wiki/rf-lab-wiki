function [x,y]=rectangularhelix(x0,y0,w,h,pn,lay)
%calculation of rectangular 
xpart1= linspace(x0,x0+w,pn);
ypart1=linspace(y0,y0,pn);
xpart2=linspace(x0+w,x0+w,pn);
ypart2=linspace(y0,y0+h,pn);
xpart3=flip(xpart1);
ypart3=flip(ypart1)+h;
xpart4=flip(xpart2)-w;
ypart4=flip(ypart2);
xperlayer=[xpart1(1:end-1) xpart2(1:end-1) xpart3(1:end-1) xpart4(1:end-1)];
yperlayer=[ypart1(1:end-1) ypart2(1:end-1) ypart3(1:end-1) ypart4(1:end-1)];
%reconstruct all layer x-y
x=repmat(xperlayer,1,lay);
y=repmat(yperlayer,1,lay);
end