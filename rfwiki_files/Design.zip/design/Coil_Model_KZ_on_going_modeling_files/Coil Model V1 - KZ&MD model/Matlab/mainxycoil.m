clear
%% coil parameters
xi=-15;
yi=-20;
wi=30;
hi=40;
r=1.5;
turn=5;
pn=100;
gap=20;
rotation=15; %in deg along x axis


%% buterfly coil construction
%pre calculation
centerlinex=xi+wi/2;
centerliney=yi+hi/2;
[x1,y1,z1]=spiralsquare(xi,yi,wi,hi,r,turn,pn);
x2=centerlinex-flip(x1);
y2=centerliney-flip(y1);
z1=flip(z1);

%shift/move 
shiftvectorx=wi+(turn-1)*4*r+gap/2+4*r;
shiftvectory=hi+(turn-1)*4*r+gap/2+4*r;
x1shifted=x1;
y1shifted=y1+shiftvectory/2;
x2shifted=x2;
y2shifted=y2-shiftvectory/2;

%rotate each side
x1rotate=x1shifted;
y1rotate=y1shifted.*cosd(rotation);
z1rotate=y1shifted.*sind(rotation);
x2rotate=x2shifted;
y2rotate=y2shifted.*cosd(-rotation);
z2rotate=y2shifted.*sind(-rotation);

%connect
connectpointx=linspace(x1rotate(end),x2rotate(1),pn);
connectpointy=linspace(y1rotate(end),y2rotate(1),pn);
connectpointz=linspace(z1rotate(end),z2rotate(1),pn);
connectpointx=connectpointx(2:end-1);
connectpointy=connectpointy(2:end-1);
connectpointz=connectpointz(2:end-1);

plot3(x1rotate,y1rotate,z1rotate,'o')
hold on
plot3(x2rotate,y2rotate,z2rotate,'*')
hold on
plot3(connectpointx,connectpointy,connectpointz,'o')
