function [xperlayer,yperlayer]=rectangularhelixsmooth(x0,y0,x1,y1,w,h,pn)
%calculation of sprial
xpart1= linspace(x0,x0+w,pn);
ypart1=linspace(y0,y0,pn);
xpart2=linspace(x0+w,x0+w,pn);
ypart2=linspace(y0,y0+h,pn);
xpart3=linspace(x0+w,x1,pn);
ypart3=linspace(y0+h,y0+h,pn);
xpart4=linspace(x1,x1,pn);
ypart4=linspace(y0+h,y1,pn);
xperlayer=[xpart1(1:end-1) xpart2(1:end-1) xpart3(1:end-1) xpart4(1:end-1)];
yperlayer=[ypart1(1:end-1) ypart2(1:end-1) ypart3(1:end-1) ypart4(1:end-1)];
end