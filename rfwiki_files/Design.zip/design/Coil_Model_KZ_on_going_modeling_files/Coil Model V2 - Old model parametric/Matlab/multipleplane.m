clear
%here unit in mm
length=[-100:100];
[x,y]=meshgrid(length);
pointsxy=[x(:),y(:)];
size=size(x(:));
z=zeros(size(1),1);
points1=[pointsxy z];
freespace.plane0=points1;
for i=1:200
    [x_new(i,:), y_new(i,:), z_new(i,:)] = rotate_and_move(points1(:,1), points1(:,2), points1(:,3), 0, 1, [0 0 i]);
end

for i=1:200
    freespace.(['plane' num2str(i)])=[x_new(i,:)' y_new(i,:)' -z_new(i,:)'];
end
%save('freespace.mat','freespace')