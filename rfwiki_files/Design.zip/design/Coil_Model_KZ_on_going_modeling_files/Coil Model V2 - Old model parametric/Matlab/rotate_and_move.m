function [x_new, y_new, z_new] = rotate_and_move(x, y, z, angle, direction, move_vector)
    % Function to rotate and move a geometry represented in 3D space
    %
    % Inputs:
    %   x, y, z        - Coordinates of the geometry
    %   angle          - Rotation angle in degrees
    %   direction      - Direction of rotation (1: x-axis, 2: y-axis, 3: z-axis)
    %   move_vector    - Vector defining the distance moved in x, y, z directions
    %
    % Outputs:
    %   x_new, y_new, z_new - Transformed coordinates of the geometry
    
    % Convert angle from degrees to radians
    angle_rad = deg2rad(angle);
    
    % Rotation matrix based on the specified direction
    switch direction
        case 1 % Rotate along x-axis
            rotation_matrix = [1 0 0; 0 cos(angle_rad) -sin(angle_rad); 0 sin(angle_rad) cos(angle_rad)];
        case 2 % Rotate along y-axis
            rotation_matrix = [cos(angle_rad) 0 sin(angle_rad); 0 1 0; -sin(angle_rad) 0 cos(angle_rad)];
        case 3 % Rotate along z-axis
            rotation_matrix = [cos(angle_rad) -sin(angle_rad) 0; sin(angle_rad) cos(angle_rad) 0; 0 0 1];
        otherwise
            error('Invalid direction specified. Use 1 for x-axis, 2 for y-axis, or 3 for z-axis.');
    end
    
    % Apply rotation
    rotated_coordinates = rotation_matrix * [x(:)'; y(:)'; z(:)'];
    
    % Translate the geometry
    x_new = rotated_coordinates(1, :) + move_vector(1);
    y_new = rotated_coordinates(2, :) + move_vector(2);
    z_new = rotated_coordinates(3, :) + move_vector(3);
end
