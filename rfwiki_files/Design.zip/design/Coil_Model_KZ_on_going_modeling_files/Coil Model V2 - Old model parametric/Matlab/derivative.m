function dAdB = derivative(A, B)
    % Function to calculate the numerical derivative of A with respect to B
    % Inputs:
    %   A - vector of function values
    %   B - vector of corresponding independent variable values
    % Output:
    %   dAdB - vector of derivative values

    % Ensure the inputs are column vectors
    A = A(:);
    B = B(:);

    % Check that A and B are the same length
    if length(A) ~= length(B)
        error('A and B must be the same length');
    end

    % Preallocate the derivative vector
    dAdB = zeros(size(A));

    % Calculate the numerical derivative using central difference method
    % for internal points and forward/backward difference for the endpoints
    for i = 2:length(A)-1
        dAdB(i) = (A(i+1) - A(i-1)) / (B(i+1) - B(i-1));
    end

    % Forward difference for the first point
    dAdB(1) = (A(2) - A(1)) / (B(2) - B(1));

    % Backward difference for the last point
    dAdB(end) = (A(end) - A(end-1)) / (B(end) - B(end-1));

    % Return the derivative vector
end