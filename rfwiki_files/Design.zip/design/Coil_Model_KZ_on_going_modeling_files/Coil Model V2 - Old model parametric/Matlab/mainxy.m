
function [xreshape,yreshape,zreshape,zlength,small_y_value,big_y_value]=mainxy(center_diameter,wire_full_diameter,layer,turnsmatrix,points)

%------pre calculation----------
r_sphere=center_diameter/2;%center circle max outter
r_matrix=[r_sphere:-2*wire_full_diameter:r_sphere-2*wire_full_diameter*(layer-1)]; %outter to inner
theta=acosd(1-((wire_full_diameter^2)./(2*(r_matrix.^2)))); %in degree in matrix


%---coil construction-----------
for i=1:layer
    tureturnmatrix(i,1:turnsmatrix(i))=[1:turnsmatrix(i)];
    if rem(turnsmatrix(i),2)==1;%odd number
        r_half_cirle_matrix(i,1:(turnsmatrix(i)-1)/2)=r_matrix(i)*sind(90-(tureturnmatrix(i,1:(turnsmatrix(i)-1)/2)*theta(i)));
        r_full_circle_matrix(i,1:turnsmatrix(i))=[flip(r_half_cirle_matrix(i,1:(turnsmatrix(i)-1)/2)) r_matrix(i) r_half_cirle_matrix(i,1:(turnsmatrix(i)-1)/2)];
        z_half_cirle_matrix(i,1:(turnsmatrix(i)-1)/2)=r_matrix(i)*cosd(90-(tureturnmatrix(i,1:(turnsmatrix(i)-1)/2)*theta(i)));
        z_full_circle_matrix(i,1:turnsmatrix(i))=[-flip(z_half_cirle_matrix(i,1:(turnsmatrix(i)-1)/2)) 0 z_half_cirle_matrix(i,1:(turnsmatrix(i)-1)/2)];
    else rem(turnsmatrix(i),2)==0;%even number
        r_half_cirle_matrix(i,1:turnsmatrix(i)/2)=r_matrix(i)*sind(90-((theta(i)/2)+(tureturnmatrix(i,1:turnsmatrix(i)/2)-1)*theta(i)));
        r_full_circle_matrix(i,1:turnsmatrix(i))=[flip(r_half_cirle_matrix(i,1:turnsmatrix(i)/2)) r_half_cirle_matrix(i,1:turnsmatrix(i)/2)];
        z_half_cirle_matrix(i,1:turnsmatrix(i)/2)=r_matrix(i)*cosd(90-((theta(i)/2)+(tureturnmatrix(i,1:turnsmatrix(i)/2)-1)*theta(i)));
        z_full_circle_matrix(i,1:turnsmatrix(i))=[-flip(z_half_cirle_matrix(i,1:turnsmatrix(i)/2)) z_half_cirle_matrix(i,1:turnsmatrix(i)/2)];
    end
end
[x,y]=circle(r_full_circle_matrix,points);


non_zero_rowx = any(x ~= 0, 2);
xnonzero = x(non_zero_rowx,:);
non_zero_rowy = any(y ~= 0, 2);
ynonzero = y(non_zero_rowy,:);
z=repelem(z_full_circle_matrix,1,points);
zreshape=trim_and_convert(z);

xreshape=reshape(xnonzero',[1 sum(turnsmatrix,"all")*points]);
yreshape=reshape(ynonzero',[1 sum(turnsmatrix,"all")*points]);
%plot3(xreshape,yreshape,zreshape)

%-------value check-----
zlength=max(zreshape)-min(zreshape)+wire_full_diameter
small_y_value=min(r_half_cirle_matrix(r_half_cirle_matrix>0))*2-wire_full_diameter
big_y_value=max(r_half_cirle_matrix,[],"all")*2+wire_full_diameter



