clear

%------parameters---This one is for Red Coil----[mm]----
%x-y coil are modeled as a spehere, so here R is consistant over
center_diameter=44; %diameter of the big spehere=overall coil R+wired/2
wire_full_diameter=2;
layer=2;
turnsmatrix=[12 10];%how many turns per layer starting from outter to inner
points=100;%points per circle
[red.xreshape,red.yreshape,red.zreshape,red.zlength,red.small_y_value,red.big_y_value]=mainxy(center_diameter,wire_full_diameter,layer,turnsmatrix,points);

%------parameters---This one is for Green Coil----[mm]----
%x-y coil are modeled as a spehere, so here R is consistant over
center_diameter=47.7; %diameter of the big spehere=overall coil R+wired/2
wire_full_diameter=2;
layer=2;
turnsmatrix=[10 7];%how many turns per layer starting from outter to inner
points=100;%points per circle
[gre.xreshape,gre.yreshape,gre.zreshape,gre.zlength,gre.small_y_value,gre.big_y_value]=mainxy(center_diameter,wire_full_diameter,layer,turnsmatrix,points);


%for greencoil
[gre.x_new, gre.y_new, gre.z_new] = rotate_and_move(gre.xreshape, gre.yreshape, gre.zreshape, 90, 2,[0 0 gre.big_y_value/2-wire_full_diameter/2]);

%for redcoil
[red.x_new, red.y_new, red.z_new] = rotate_and_move(red.xreshape, red.yreshape, red.zreshape, 90, 1,[0 0 gre.big_y_value/2-wire_full_diameter/2]);


blue=load('bluecoilolddesign.mat');

plot3(blue.x_new,blue.y_new,blue.z_new)
hold on
plot3(red.x_new,red.y_new,red.z_new)
hold on
plot3(gre.x_new,gre.y_new,gre.z_new,'g')

%data formating
bluecenterline=[blue.x_new;blue.y_new;blue.z_new]';
grecenterline=[gre.x_new;gre.y_new;gre.z_new]';
redcenterline=[red.x_new;red.y_new;red.z_new]';

save("bluecenterline.mat","bluecenterline");
save("grecenterline.mat","grecenterline");
save("redcenterline.mat","redcenterline");
