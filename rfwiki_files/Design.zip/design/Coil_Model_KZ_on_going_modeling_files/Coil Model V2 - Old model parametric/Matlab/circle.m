function [x, y] = circle(r, n_points)
    % Function to generate points on circles with given radii
    %
    % Inputs:
    %   r        - Matrix of radii
    %   n_points - Number of points to generate on each circle
    %
    % Outputs:
    %   x, y     - Coordinates of the points on the circles

    % Number of circles to generate
    [rows, cols] = size(r);
    num_circles = rows * cols;
    
    % Pre-allocate arrays for coordinates
    x = zeros(num_circles, n_points);
    y = zeros(num_circles, n_points);
    
    % Angles for n_points evenly spaced points on a circle
    theta = linspace(0, 2*pi, n_points + 1);
    theta(end) = []; % Remove the last point to avoid duplication of the first point
    
    % Counter for circle index
    circle_idx = 1;
    
    % Loop through each radius in the matrix row by row
    for row = 1:rows
        for col = 1:cols
            % Current radius
            radius = r(row, col);
            
            % Generate points for the current circle
            x(circle_idx, :) = radius * cos(theta);
            y(circle_idx, :) = radius * sin(theta);
            
            % Increment circle index
            circle_idx = circle_idx + 1;
        end
    end
end