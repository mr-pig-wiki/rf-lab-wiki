clear
%------parameters-------[mm]----
outter_diameter=48;%centerline
wire_full_diameter=2;
layer=4;
turnmatrix=[6 5 4 3]; %how many turns on botton layer(big number/close to skull) -> how many turns on the top layer(small number/far to skull)

points=100;%points per circle not important 
%check turn and turn matrix size
if length(turnmatrix)==layer;
    fprintf('-------ok go ahead-------')
end

%------pre calculation----------
outter_radius=outter_diameter/2;
inner_diameter=outter_diameter-wire_full_diameter*(turnmatrix-1).*2; %matrix
inner_radius=inner_diameter./2;

raidusmatrix=zeros(layer,max(turnmatrix));
for i=1:layer
    raidusmatrix(i,1:turnmatrix(i))=[outter_radius:(-1)*wire_full_diameter:inner_radius(i)];
end

%---coil construction-----------
m=layer; %row 
n=points*length(raidusmatrix);%column
x=zeros(m, n);
y=zeros(m, n);
z=zeros(m, n);

for i =1: layer
    for ii=1: length(raidusmatrix)
        [xnew,ynew]=circle(raidusmatrix(i,ii),points);
        x(i,(ii-1)*100+1:ii*100)=xnew;
        y(i,(ii-1)*100+1:ii*100)=ynew;
        z(i,:)=(i-1)*2;
    end
end
xreshape=reshape(x',[1,m*n]);
yreshape=reshape(y',[1,m*n]);
zreshape=reshape(z',[1,m*n]);

for i=m*n:-1:1
    if xreshape(i)==0 & yreshape(i)==0
        xreshape(i)=[];
        yreshape(i)=[];
        zreshape(i)=[];
    end
end

plot3(xreshape,yreshape,zreshape)


[x_new, y_new, z_new] = rotate_and_move(xreshape, yreshape, zreshape, 0, 1,[0 0 0]);
plot3(x_new, y_new, z_new)
save("bluecoilolddesign.mat","x_new","y_new","z_new");