% close all, 
clear all

s = tf('s');

% Input resistance
% Rin = 78e3;
% Zin = tf(3.27*78e3);
Zin = tf(78e3);  % R2+R4 or R3+R5

% Differential Impedence.
Rdiff = 22e3;
Zdiff = tf(Rdiff);

%  scale_factor = 1.35;  % MIT tabletop gradient compensation
  scale_factor = 1;
% Feedback Impedance (one side)
Rf = scale_factor*51e3;   % 51e3 --> R10 and R11
Zf = tf(Rf);
Cc = 1.5e-9%100e-12;   %   ~100e-12 for shim coil,  200e-12 for MIT tabletop gradients --> C2 and C1
Rc = scale_factor*5.1e3;    % 5.1e3 --> R12 and R13
Zc = tf(Rc) + 1/(Cc*s);
Zfc = minreal((Zc * Zf)/(Zc+Zf));

%Load Impedance
Rl = 2%.5;
Ll = 690e-6%10e-6;   % 40-53uH for MIT tabletop gradients
Zl = tf(Ll*s + Rl);

% Sense Impedance
Rs = 0.2; % current sense resistor on push OPA549 output in series with load shim coil
Zs = tf(Rs);

% Op-amp
Hopa = tf(7.5e13/((s+20)*(s+1e7))); % Op-amp gain --> comes from data sheet
Hinv = minreal(tf(-0.5*feedback(Hopa,0.5))); % Inverting Unity Gain.

% From op amp output to voltage across sense resistor
%Kl = minreal(tf((1 - Hinv)*Zs/(Zl+Zs))); % (1-Hinv) for bipolar drive.
Kl = minreal(tf((2)*Zs/(Zl+Zs))); % 2 is simple model for bipolar drive.

% From sense voltage to differential voltage.
ZdiffZin = (Zdiff*2*Zin/(Zdiff+2*Zin));
Kfb = ZdiffZin/(ZdiffZin + 2*Zfc);

% Loop gain
W = minreal(Hopa*Kl*Kfb);


% Feedback loop (output is voltage across sense resistor)
Drv = feedback(Hopa*Kl, Kfb);

% Input Gain -- original version with no filter cap
ZdiffZfc = (Zdiff*2*Zfc/(Zdiff+2*Zfc));
Kin = ZdiffZfc/(ZdiffZfc+2*Zin);

% % add in filter capacitor between 68e3 and 10e3 resistors
% Zin = tf((20e3 * 22e3) / (20e3 + 22e3));
% Cf = tf(3/(s*1e-12));
% Zp = tf(Cf*Zin/(Cf + Zin));
% Kin = tf(2*68e3*Zp/(Zp + 2*68e3));




% Input to coil current
V2A = Drv*Kin/Zs;

% Input to voltage across coil
V2Vc = V2A*Zl;


% plot results
figure(1),margin(W)
% figure(2),step(tf(V2Vc)),set(gca,'LineWidth',2,'FontSize',28),xlim([-20e-6 300e-6]),title('voltage drop across gradient coil load','FontSize',28),ylabel('Voltage','FontSize',28),xlabel('time','FontSize',28)
% set(gca,'LineWidth',3)

figure(3),step((V2Vc)),set(gca,'LineWidth',2,'FontSize',28),title('voltage through load','FontSize',28),xlim([-20e-6 300e-6]),ylabel('ratio: output current / input voltage','FontSize',28),xlabel('time','FontSize',28)

figure(4),step((V2A)),set(gca,'LineWidth',2,'FontSize',28),title('current through load','FontSize',28),xlim([-20e-6 300e-6]),ylabel('ratio: output current / input voltage','FontSize',28),xlabel('time','FontSize',28)

            
            





