1-layer Aluminum-core, 1.6 mm thickness with 1 W/(m*K) insulator, 1 oz copper
Lead-free (RoHS) HASL plating on pads, LPI soldermask and silkscreen on top side
Overall dimensions 290 x 110 mm (11.417" x 4.331")
Min. trace/spacing 0.2 mm (0.0079")
Min. hole size 3.2 mm (0.126")
All copper layers positive

*-Edge_Cuts.gm1: Board outline
*-F_Cu.gtl: Top copper
*-F_Mask.gts: Top soldermask
*-F_SilkS.gto: Top silkscreen
*.drl: Drill file (plated holes) - can connect to aluminum core
*-drl_map.pdf: Drill map (plated holes) - can connect to aluminum core
*-Fab.pdf: Fabrication drawing

*-AssyTop.pdf: Assembly drawing
*-F_Paste.gtp: Top solder paste
* BOM.xls: Bill of Materials
*-all.pos, *-all-pos.csv: Pick-and-place centroid component positions