2 layers
Overall dimensions 129 x 68.5 mm (5.079" x 2.697")
All copper layers positive
Min. trace/spacing 0.2 mm (0.0079")
Min. hole size 0.4 mm (0.0157")

*-F_Cu.gbr: Top (layer 1) copper
*-B_Cu.gbr: Bottom (layer 2) copper
*-F_Mask.gbr: Top soldermask
*-B_Mask.gbr: Bottom soldermask
*-F_SilkS.gbr: Top silkscreen
*-B_SilkS.gbr: Bottom silkscreen
*-Edge_Cuts.gbr: Outline
*-PTH.drl: Drill file (plated holes)
*-NPTH.drl: Drill file (non-plated holes)